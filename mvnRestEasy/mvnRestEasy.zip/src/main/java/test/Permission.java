package test;

public enum Permission {
    VIEW, EDIT, DELETE, CREATE, COMPLETE, REASSIGN;
}
