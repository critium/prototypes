package test;

public enum Resource {
    CaseData, OfficeAction;
}
